# CS553 Cloud Computing Fall 2023 Programming Assignment 2
**Illinois Institute of Technology**  
Student: Khalil-Sani-Muhammad (Ksani@hawk.iit.edu)

TO-DO: submit source code (Makefile, C code and Bash scripts) and the performance report (PA2-report.pdf).

