#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

// Constants for access patterns
#define READ_SEQUENTIAL 0
#define READ_RANDOM 1
#define WRITE_SEQUENTIAL 2
#define WRITE_RANDOM 3

// Constants for record sizes
#define SIZE_64KB (64 * 1024)
#define SIZE_1MB (1024 * 1024)
#define SIZE_16MB (16 * 1024 * 1024)

// Function to perform file read operation
void readFile(const char* filename, int accessPattern, int recordSize) {
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char* buffer = malloc(recordSize);
    if (buffer == NULL) {
        perror("Error allocating memory");
        exit(EXIT_FAILURE);
    }

    // Measure time taken for read operations
    clock_t start = clock();
    off_t offset = 0;
    while (1) {
        if (accessPattern == READ_RANDOM) {
            offset = lseek(fd, rand() % (recordSize * 1000), SEEK_SET);
            if (offset == -1) {
                perror("Error seeking file");
                exit(EXIT_FAILURE);
            }
        }
        ssize_t bytesRead = read(fd, buffer, recordSize);
        if (bytesRead == -1) {
            perror("Error reading file");
            exit(EXIT_FAILURE);
        }
        if (bytesRead == 0) {
            break; // Reached end of file
        }
    }
    clock_t end = clock();

    double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
    double opsPerSec = 1.0 / timeTaken;

    printf("Access Pattern: %s, Record Size: %d bytes\n", accessPattern == READ_SEQUENTIAL ? "Sequential Read" : "Random Read", recordSize);
    printf("Operations Per Second (OPS/sec): %.2f\n", opsPerSec);

    free(buffer);
    close(fd);
}

// Function to perform file write operation
void writeFile(const char* filename, int accessPattern, int recordSize) {
    int fd = open(filename, O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR);
    if (fd == -1) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char* buffer = malloc(recordSize);
    if (buffer == NULL) {
        perror("Error allocating memory");
        exit(EXIT_FAILURE);
    }

    // Fill buffer with data to be written
    memset(buffer, 'A', recordSize);

    // Measure time taken for write operations
    clock_t start = clock();
    for (int i = 0; i < 1000; i++) { // Write 1000 records
        if (accessPattern == WRITE_RANDOM) {
            off_t offset = lseek(fd, rand() % (recordSize * 1000), SEEK_SET);
            if (offset == -1) {
                perror("Error seeking file");
                exit(EXIT_FAILURE);
            }
        }
        ssize_t bytesWritten = write(fd, buffer, recordSize);
        if (bytesWritten == -1) {
            perror("Error writing to file");
            exit(EXIT_FAILURE);
        }
    }
    clock_t end = clock();

    double timeTaken = ((double)(end - start)) / CLOCKS_PER_SEC;
    double opsPerSec = 1000.0 / timeTaken;

    printf("Access Pattern: %s, Record Size: %d bytes\n", accessPattern == WRITE_SEQUENTIAL ? "Sequential Write" : "Random Write", recordSize);
    printf("Operations Per Second (OPS/sec): %.2f\n", opsPerSec);

    free(buffer);
    close(fd);
}

int main(int argc, char* argv[]) {
    if (argc != 5) {
        printf("Usage: %s <access_pattern> <record_size> <dataset_config> <concurrency>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int accessPattern = atoi(argv[1]);
    int recordSize = atoi(argv[2]);
    const char* datasetConfig = argv[3];
    int concurrency = atoi(argv[4]);

    srand(time(NULL));

    // Generate datasets based on datasetConfig (D1 to D8)

    // Perform file I/O operations with specified access pattern and record size
    if (accessPattern == READ_SEQUENTIAL || accessPattern == READ_RANDOM) {
        // Read operations
        for (int i = 0; i < concurrency; i++) {
            char filename[50];
            snprintf(filename, sizeof(filename), "dataset_%s/file%d.bin", datasetConfig, i + 1);
            readFile(filename, accessPattern, recordSize);
        }
    } else if (accessPattern == WRITE_SEQUENTIAL || accessPattern == WRITE_RANDOM) {
        // Write operations
        for (int i = 0; i < concurrency; i++) {
            char filename[50];
            snprintf(filename, sizeof(filename), "dataset_%s/file%d.bin", datasetConfig, i + 1);
            writeFile(filename, accessPattern, recordSize);
        }
    } else {
        printf("Invalid access pattern\n");
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

