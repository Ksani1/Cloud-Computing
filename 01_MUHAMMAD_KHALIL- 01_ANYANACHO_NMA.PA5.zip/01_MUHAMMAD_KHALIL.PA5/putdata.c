#include <stdio.h>
#include <stdlib.h>

int main() {
    system("ls");  // This command lists the contents of the current directory

    FILE *TestFile;
    char ch;
    TestFile = fopen("data2.in", "r");

    if (NULL == TestFile) {
        printf("File can't be opened \n");
        return 1;  // Return an error code
    }

    printf("Content of this file:\n");
    char key[11] = "";  // Increased the size of the key array to accommodate the null terminator
    char value[89] = "";  // Decreased the size to 89 to leave room for null terminator

    int i = 0;  // Variable for key array index
    int j = 0;  // Variable for value array index
    int c = 0;  // Counter for characters read

    do {
        ch = fgetc(TestFile);

        if (i < 10) {
            key[i] = ch;
            i++;
        }

        if ((c > 11) && (j < 88)) {  // Corrected the array index to 88
            value[j] = ch;
            j++;
        }

        c++;

        if (c > 98) {
            // Print key and value
            printf("Key: %s\n", key);
            printf("Value: %s\n", value);

            // Reset indices and counters
            i = 0;
            j = 0;
            c = 0;

            // Assuming "db.test1" is a MongoDB collection, this line will not work directly in C
            // You need to use a MongoDB C driver to interact with the database

            // Below is just a placeholder; replace this line with proper MongoDB C driver code
            // to insert into the database based on your requirements
            // system("db.test1.insertOne({ key: key, value: value })");
            
            printf("Placeholder: Insert into MongoDB collection\n");
        }
    } while (ch != EOF);

    fclose(TestFile);
    return 0;
}
