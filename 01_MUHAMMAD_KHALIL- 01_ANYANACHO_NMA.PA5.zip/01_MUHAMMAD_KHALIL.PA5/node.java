import redis.clients.jedis.HostAndPort;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import redis.clients.jedis.Jedis;
import java.util.*;

public class ReadData {

    // Method to read specified number of lines from a file
    private static String[] readLines(String filePath, int numLines) {
        String[] array = new String[numLines];
        try (BufferedReader buffer = new BufferedReader(new FileReader(filePath))) {
            int n = 0;
            String str;
            while ((str = buffer.readLine()) != null) {
                if (n >= numLines) break;
                array[n] = str;
                n++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return array;
    }

    public static void main(String[] args) {
        // Check if the required command-line arguments are provided
        if (args.length < 2) {
            System.out.println("Usage: java ReadData <filePath> <numLines>");
            return;
        }

        // Extract command-line arguments
        String filePath = args[0];
        int numLines = Integer.parseInt(args[1]);

        // Read specified number of lines from the file
        String[] genString = readLines(filePath, numLines);

        // Set up Jedis instance to connect to Redis
        Jedis jc = new Jedis("10.186.189.77", 6379);

        // Execution time measurement for Insert operation
        long startTime = System.currentTimeMillis();
        for (String s : genString) {
            jc.set(s.substring(0, 11), s.substring(12, 96));
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Execution time for Insert: " + (endTime - startTime));

        // Execution time measurement for Lookup operation
        startTime = System.currentTimeMillis();
        for (String s : genString) {
            jc.get(s.substring(0, 11));
        }
        endTime = System.currentTimeMillis();
        System.out.println("Execution time for Lookup: " + (endTime - startTime));

        // Execution time measurement for Deletion operation
        startTime = System.currentTimeMillis();
        for (String s : genString) {
            jc.del(s.substring(0, 11));
        }
        endTime = System.currentTimeMillis();
        System.out.println("Execution time for Deletion: " + (endTime - startTime));
    }
}
