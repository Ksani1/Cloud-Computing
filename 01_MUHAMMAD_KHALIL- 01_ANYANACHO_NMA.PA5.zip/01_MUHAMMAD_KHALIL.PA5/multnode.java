import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class ReadData {

    // Method to read specified number of lines from a file
    private static String[] readLines(String filePath, int numLines) {
        String[] array = new String[numLines];
        try (BufferedReader buffer = new BufferedReader(new FileReader(filePath))) {
            int n = 0;
            String str;
            while ((str = buffer.readLine()) != null && n < numLines) {
                array[n] = str;
                n++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return array;
    }

    public static void main(String[] args) {
        // Check if the required command-line arguments are provided
        if (args.length < 2) {
            System.out.println("Usage: java ReadData <filePath> <numLines>");
            return;
        }

        // Extract command-line arguments
        String filePath = args[0];
        int numLines = Integer.parseInt(args[1]);

        // Read specified number of lines from the file
        String[] dataLines = readLines(filePath, numLines);

        // Set up Redis cluster nodes
        Set<HostAndPort> jedisClusterNodes = new HashSet<>();
        jedisClusterNodes.add(new HostAndPort("10.186.189.249", 6379));
        jedisClusterNodes.add(new HostAndPort("10.186.189.19", 6379));
        jedisClusterNodes.add(new HostAndPort("10.186.189.182", 6379));
        jedisClusterNodes.add(new HostAndPort("10.186.189.112", 6379));
        jedisClusterNodes.add(new HostAndPort("10.186.189.207", 6379));
        jedisClusterNodes.add(new HostAndPort("10.186.189.56", 6379));
        jedisClusterNodes.add(new HostAndPort("10.186.189.191", 6379));
        jedisClusterNodes.add(new HostAndPort("10.186.189.86", 6379));

        try (JedisCluster jc = new JedisCluster(jedisClusterNodes)) {

            long startTime = System.currentTimeMillis();
            // Insert data into Redis cluster
            for (String line : dataLines) {
                jc.set(line.substring(0, 11), line.substring(12, 96));
            }
            long endTime = System.currentTimeMillis();
            System.out.println("Execution time for Insert: " + (endTime - startTime));

            startTime = System.currentTimeMillis();
            // Look up data from Redis cluster
            for (String line : dataLines) {
                jc.get(line.substring(0, 11));
            }
            endTime = System.currentTimeMillis();
            System.out.println("Execution time for Lookup: " + (endTime - startTime));

            startTime = System.currentTimeMillis();
            // Delete data from Redis cluster
            for (String line : dataLines) {
                jc.del(line.substring(0, 11));
            }
            endTime = System.currentTimeMillis();
            System.out.println("Execution time for Deletion: " + (endTime - startTime));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
