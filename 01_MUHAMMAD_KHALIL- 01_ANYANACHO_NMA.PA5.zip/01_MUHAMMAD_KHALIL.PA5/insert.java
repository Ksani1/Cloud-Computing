package com.bhavya.app;

import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner;
import java.lang.*;
import com.datstax.oss.driver.api.core.CqlSession;
import com.datstax.oss.driver.api.core.cql.*;
import java.net.InetSocketAddress;
import com.datstax.oss.driver.api.core.CqlIdentifier;

public class App {
    public static void main(String[] args) {
        // Record start time for performance measurement
        long s_time = System.currentTimeMillis();

        float cn = 0;
        String value="", key="";
        try {
            // Read data from file
            File obj = new File("dat50.in");
            Scanner read = new Scanner(obj);

            // Process each line in the file
            while (read.hasNextLine()) {
                String dat = read.nextLine();

                // Extract key from the first 10 characters
                for (int j = 0; j < 10; j++) {
                    if (dat.indexOf("'") != -1) {
                        key += "s";
                    } else {
                        key += dat.charAt(j);
                    }
                }

                // Extract value from the rest of the characters
                for (int j = 11; j < (dat.length()); j++)
                    value += dat.charAt(j);

                // Establish Cassandra session and execute INSERT query
                try (CqlSession session = CqlSession.builder()
                        .addContactPoint(new InetSocketAddress("10.149.12.226", 9042))
                        .withLocalDatacenter("datcenter1")  // Fix typo in method name
                        .withKeyspace(CqlIdentifier.fromCql("prod"))
                        .build()) {

                    // Construct the INSERT query with the extracted key and value
                    String query3 = "INSERT INTO gen(id, value) VALUES('"+key+"', '"+value+"');";

                    cn++;
                    session.execute(query3);
                    System.out.println("Done "+(((cn*100.0)/500.0))+"%");
                }

                // Reset key and value for the next iteration
                key = "";
                value = "";
            }
            // Close the file reader
            read.close();

        } catch (FileNotFoundException e) {
            // Handle file not found exception
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        // Record end time for performance measurement
        long f_time = System.currentTimeMillis();
        long totaltime = f_time - s_time;

        // Print total time taken
        System.out.println("time: " + totaltime);
    }
}
