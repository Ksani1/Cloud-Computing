#include <stdio.h>
#include <stdlib.h>

int main() {
    system("ls");  // This command lists the contents of the current directory

    FILE *TestFile;
    char ch;
    TestFile = fopen("data2.in", "r");

    if (NULL == TestFile) {
        printf("File can't be opened \n");
        return 1;  // Return an error code
    }

    printf("Content of this file:\n");
    char key[11] = "";  // Increased the size of the key array to accommodate the null terminator
    char value[88] = "";  // Decreased the size to 88 to leave room for null terminator

    int i = 0;  // Variable for key array index
    int j = 0;  // Variable for value array index
    int c = 0;  // Counter for characters read

    do {
        ch = fgetc(TestFile);

        if (i < 10) {
            key[i] = ch;
            i++;
        }

        if ((c > 11) && (j < 87)) {
            value[j] = ch;
            j++;
        }

        c++;

        if (c > 98) {
            // Print key and value
            printf("Key: %s\n", key);
            printf("Value: %s\n", value);

            // Reset indices and counters
            i = 0;
            j = 0;
            c = 0;

            // Assuming jc.set is a function you want to call, use appropriate arguments
            // The following line demonstrates the function call with key and value as arguments
            // Replace this line with the actual function call based on your requirements
            // jc.set(key, value);

            printf("jc.set(key, value) called\n");
        }

    } while (ch != EOF);

    fclose(TestFile);
    return 0;
}
