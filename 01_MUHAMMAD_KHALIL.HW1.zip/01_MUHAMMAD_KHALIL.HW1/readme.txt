This program is specifically tailored to handle various file sizes while adhering to an 1 GB, 8 GB, 4 GB, 16 GB, 64 GB memory limit.

DATASET GENERATION:
To generate a dataset, use the following command format:

./gensort -a <no_of_records> <file_name> &

- <no_of_records>: Number of records to generate. Each record is 100 bytes.
- <file_name>: Name of the file for the generated data.

COMPILATION:
Compile the program using the makefile provided:

make

EXECUTION:
Run the Java program with the following command format:

java MySort.java <input_file> <output_file> <thread_cnt>

- <input_file>: File containing the input dataset.
- <output_file>: File to store the sorted dataset.
- <thread_cnt>: Number of threads. Default is 4. 

To limit the memory size to 8GB, use the following command format:

java -Xmx8g MySort.java <input_file> <output_file> <thread_cnt>

VERIFICATION:
To verify the sorted file using valsort, utilize the command:

./valsort <file_name>

USING LINUX SORT:
To employ Linux sort, utilize the following command format:

LC_ALL=C sort --buffer-size=<memory> --parallel=<no_of_threads> <input_file> -o <output_file>

- <memory>: Size of the memory you want to allocate for sorting.
- <no_of_threads>: Number of threads for parallel sorting.
- <input_file>: Input file name.
- <output_file>: Output file name.

Example usage:

LC_ALL=C sort --buffer-size=8g --parallel=16 input_64.txt -o out_64.txt &

This command will sort input_64.txt using 8GB of RAM and 16 threads, and the sorted data will be stored in out_64.txt.

Make sure to follow these instructions when using the Java program for data sorting, considering the 8GB memory constraint.
