#!/bin/bash

if [ "$#" -ne 1 ]; then
    echo "Usage: sort-data.sh <input_file>"
    exit 1
fi

input_file="$1"

# Sort the file based on the first column (numerically)
time sort -n -k1 -o "$input_file" "$input_file"

