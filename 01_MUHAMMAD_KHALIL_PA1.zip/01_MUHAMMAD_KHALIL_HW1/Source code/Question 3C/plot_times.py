import matplotlib.pyplot as plt

num_records = [1000, 100000, 10000000]
generate_times = [18.308, 14.701, 3.852] 
sort_times = [0.026, 0.157, 0.021]  

plt.figure(figsize=(8, 5))
plt.plot(num_records, generate_times, marker='o', label='Data Generation')
plt.plot(num_records, sort_times, marker='o', label='Data Sorting')

plt.xlabel('Number of Records')
plt.ylabel('Time (seconds)')
plt.title('Time vs. Number of Records')

plt.legend()

plt.grid()
plt.show()

