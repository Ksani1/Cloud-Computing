#!/bin/bash

if [ "$#" -ne 2 ]; then
    echo "Usage: generate-dataset.sh <filename> <num_records>"
    exit 1
fi

filename="$1"
num_records="$2"

# Function to generate a random 32-bit integer
generate_random_integer() {
    echo $((RANDOM % 2147483647))
}

# Function to generate a random ASCII string of 100 characters
generate_random_ascii_string() {
    tr -c -d '[:print:]' < /dev/urandom | head -c 100
}

# Generate the dataset
start_time=$(date +%s)
while [ "$(($(date +%s) - start_time))" -lt 10 ]; do
    for ((i = 0; i < num_records; i++)); do
        echo "$(generate_random_integer) $(generate_random_integer) $(generate_random_ascii_string)"
    done
done > "$filename"

# Count the number of records in the file
record_count=$(wc -l < "$filename")
echo "Generated $record_count records in $filename"

