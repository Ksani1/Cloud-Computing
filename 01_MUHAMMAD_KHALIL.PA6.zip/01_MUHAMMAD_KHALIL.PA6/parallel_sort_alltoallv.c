#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

void merge(int *a, int n) {
  int *b = malloc(n * sizeof(int));
  int i = 0, j = n / 2, k = 0;
  while (i < n / 2 && j < n) {
    if (a[i] <= a[j]) {
      b[k] = a[i];
      i++;
    } else {
      b[k] = a[j];
      j++;
    }
    k++;
  }
  while (i < n / 2) {
    b[k] = a[i];
    i++;
    k++;
  }
  while (j < n) {
    b[k] = a[j];
    j++;
    k++;
  }
  memcpy(a, b, n * sizeof(int));
  free(b);
}

void parallel_sort_alltoallv(int *a, int n) {
  int rank, size;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  // Create a send and receive buffer for each process
  int *send_buf = malloc(n * sizeof(int));
  int *recv_buf = malloc(n * sizeof(int));

  // Calculate the send and receive counts
  int send_counts[size];
  int recv_counts[size];
  for (int i = 0; i < size; i++) {
    send_counts[i] = n / size;
    recv_counts[i] = n / size;
  }
  if (rank == 0) {
    send_counts[0] = n % size;
  }
  if (rank == size - 1) {
    recv_counts[size - 1] = n % size;
  }

  // Calculate the send and receive displacements
  int send_displs[size];
  int recv_displs[size];
  send_displs[0] = 0;
  recv_displs[0] = 0;
  for (int i = 1; i < size; i++) {
    send_displs[i] = send_displs[i - 1] + send_counts[i - 1];
    recv_displs[i] = recv_displs[i - 1] + recv_counts[i - 1];
  }

  // Perform the Alltoallv collective call
  MPI_Alltoallv(a, send_counts, send_displs, MPI_INT, recv_buf, recv_counts,
              recv_displs, MPI_INT, MPI_COMM_WORLD);

  // Merge the sorted chunks on each process
  merge(recv_buf, n);

  // Copy the sorted data back to the original array
  memcpy(a, recv_buf, n * sizeof(int));

  free(send_buf);
  free(recv_buf);
}

int main(int argc, char *argv[]) {
  int rank, size;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  int n = 10;
  int a[n];
  for (int i = 0; i < n; i++) {
    a[i] = rand() % 100;
  }

  // Print the unsorted array
  if (rank == 0) {
    printf("Unsorted array: ");
    for (int i = 0; i < n; i++) {
      printf("%d ", a[i]);
    }
    printf("\n");
  }

  // Sort the array
  parallel_sort_alltoallv(a, n);

  // Print the sorted array
  if (rank == 0) {
    printf("Sorted array: ");
  // Print the sorted array
  if (rank == 0) {
    printf("Sorted array: ");
    for (int i = 0; i < n; i++) {
      printf("%d ", a[i]);
    }
    printf("\n");
  }

  MPI_Finalize();
  return 0;
}
